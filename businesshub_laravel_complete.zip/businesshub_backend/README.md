# BusinessHub - Multi-Business Management Platform

A comprehensive Laravel backend API for managing multiple businesses including agriculture, food processing, delivery, bricks manufacturing, and more.

## Features

- **Multi-Tenant Architecture**: Manage multiple businesses under one account
- **Multi-Language Support**: 13 Indian languages (Hindi, Bengali, Marathi, Odia, Assamese, Telugu, Tamil, Punjabi, Gujarati, Kannada, Malayalam, Urdu)
- **Product Management**: Track products, services, stock levels with automatic alerts
- **Invoice Management**: Generate invoices, track payments, send reminders
- **Customer Management**: Farmer and trader profiles with credit tracking
- **Financial Tracking**: Income, expense, and profit analysis
- **Reporting**: Dashboard analytics, monthly trends, category-wise reports
- **PDF Generation**: Download and print invoices
- **Real-time Notifications**: Low stock alerts, payment reminders

## Requirements

- PHP 8.2+
- MySQL 8.0+ or PostgreSQL
- Composer 2.0+
- Redis (optional, for caching)

## Installation

### Step 1: Install Dependencies

```bash
composer install
```

### Step 2: Configure Environment

```bash
cp .env.example .env
php artisan key:generate
```

Edit `.env` file with your database credentials:

```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=businesshub
DB_USERNAME=root
DB_PASSWORD=your_password
```

### Step 3: Run Migrations

```bash
php artisan migrate
```

### Step 4: Install Sanctum (for API authentication)

```bash
php artisan vendor:publish --provider="Laravel\Sanctum\SanctumServiceProvider"
php artisan migrate
```

### Step 5: Seed Database (Optional - creates sample data)

```bash
php artisan db:seed
```

### Step 6: Start Server

```bash
php artisan serve
```

The API will be available at `http://127.0.0.1:8000/api`

## Default Login Credentials (after seeding)

- **Email**: rajesh@businesshub.com
- **Phone**: +919876543210
- **Password**: password123

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login
- `POST /api/auth/logout` - Logout
- `GET /api/auth/profile` - Get profile
- `PUT /api/auth/profile` - Update profile
- `POST /api/auth/change-password` - Change password

### Business Management
- `GET /api/businesses` - List businesses
- `POST /api/businesses` - Create business
- `GET /api/businesses/{business}` - Get business details
- `GET /api/businesses/{business}/dashboard` - Dashboard stats
- `POST /api/businesses/{business}/switch` - Switch active business

### Products
- `GET /api/businesses/{business}/products` - List products
- `POST /api/businesses/{business}/products` - Create product
- `GET /api/businesses/{business}/products/low-stock` - Low stock alerts
- `POST /api/businesses/{business}/products/{product}/adjust-stock` - Adjust stock

### Invoices
- `GET /api/businesses/{business}/invoices` - List invoices
- `POST /api/businesses/{business}/invoices` - Create invoice
- `POST /api/businesses/{business}/invoices/{invoice}/mark-paid` - Record payment
- `GET /api/businesses/{business}/invoices/{invoice}/download-pdf` - Download PDF

### Customers
- `GET /api/businesses/{business}/customers` - List customers
- `POST /api/businesses/{business}/customers` - Create customer
- `GET /api/businesses/{business}/customers/stats` - Customer statistics

### Transactions
- `GET /api/businesses/{business}/transactions` - List transactions
- `POST /api/businesses/{business}/transactions` - Record transaction
- `GET /api/businesses/{business}/transactions/summary` - Financial summary

### Reports
- `GET /api/businesses/{business}/reports/dashboard` - Dashboard report
- `GET /api/businesses/{business}/reports/income` - Income report
- `GET /api/businesses/{business}/reports/expense` - Expense report
- `GET /api/businesses/{business}/reports/dues` - Dues report
- `GET /api/businesses/{business}/reports/stock` - Stock report

### Language
- `GET /api/languages` - List supported languages
- `POST /api/language` - Set language
- `GET /api/translations` - Get translations

## Language Support

The API supports 13 Indian languages:
- English (en)
- Hindi (hi) - Default
- Bengali (bn)
- Marathi (mr)
- Odia (or)
- Assamese (as)
- Telugu (te)
- Tamil (ta)
- Punjabi (pa)
- Gujarati (gu)
- Kannada (kn)
- Malayalam (ml)
- Urdu (ur)

Set language via header: `Accept-Language: hi`
Or via API: `POST /api/language` with `{ "language": "hi" }`

## License

MIT License
